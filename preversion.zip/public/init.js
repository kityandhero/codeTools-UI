const appInitCustom = {
  platformName: '数据层框架构建工具',
  appName: '数据层框架构建工具',
  loginLogo: '/logo.png',
  shareLogo: '/shareLogo.png',
  shareLogoName: '数据层框架构建工具',
  companyName: '数据层框架构建工具',
  apiPrefix: {
    corsTargetProduction: 'https://api2.yurukeji.com.cn',
  },
};
