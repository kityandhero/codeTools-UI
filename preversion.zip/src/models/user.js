import { query as queryUsers, queryCurrent } from '@/services/user';
import { pretreatmentRemoteSingleData } from '@/utils/tools';

export default {
  namespace: 'user',

  state: {
    list: [],
    currentUser: {},
  },

  effects: {
    *fetch(_, { call, put }) {
      const response = yield call(queryUsers);
      yield put({
        type: 'save',
        payload: response,
      });
    },
    *fetchCurrent(_, { call, put }) {
      const response = yield call(queryCurrent);
      yield put({
        type: 'saveCurrentUser',
        payload: response,
      });
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        list: action.payload,
      };
    },
    saveCurrentUser(state, action) {
      const d = action.payload;
      const v = pretreatmentRemoteSingleData(d);
      const { data } = v;

      return {
        ...state,
        currentUser: data || { notifyCount: 0 },
      };
    },
    changeNotifyCount(state, action) {
      return {
        ...state,
        currentUser: {
          ...state.currentUser,
          notifyCount: action.payload || 0,
        },
      };
    },
  },
};
