module.exports = {
  fieldData: {
    cityName: '地区',
    balance: '当前余额',
    amount: '提现金额',
    bank: '收款账户',
    inTime: '提交时间',
  },
};
