module.exports = {
  fieldData: {
    advertisementId: '广告编号',
    title: '标题',
    className: '所属类别',
    classId: '所属类别',
    imageUrl: '图片',
    url: '链接地址',
    sort: '排序值',
    inTime: '创建时间',
    operate: '操作',
    keywords: '关键词',
  },
};
