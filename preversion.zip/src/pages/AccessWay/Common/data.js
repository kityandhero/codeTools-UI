module.exports = {
  fieldData: {
    accessWayId: '模块标识',
    channel: '系统名',
  },
};
