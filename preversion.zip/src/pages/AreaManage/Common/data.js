module.exports = {
  fieldData: {
    areaManageId: '账户标识',
    areaAgentId: '地区标识',
    name: '名称',
    phone: '手机号码',
    loginName: '登录名',
    password: '登录密码',
    rePassword: '验证密码',
    state: '状态',
    roleNameCollection: '角色信息',
    inTime: '创建时间',
  },
};
