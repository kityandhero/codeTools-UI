module.exports = {
  fieldData: {
    keyword: '关键词',
    state: '状态',
    areaAgentName: '地区账户名称',
    userId: '用户Id',
    isCloseShop: '站长店铺开关',
    amount: '总金额',
    weChatName: '微信号',
    name: '账户名称',
    bankName: '银行名称',
    bankNo: '银行卡号',
    reason: '金额名称',
    applyTime: '申请时间',
    handleNote: '财务处理备注',
  },
};
