module.exports = {
  fieldData: {
    callCenterId: '数据标识',
    title: '客服名称',
    description: '简介描述',
    contactInformation: '联系方式',
    sort: '排序值',
    inTime: '添加时间',
  },
};
