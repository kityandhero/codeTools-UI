import dva from 'dva';
import createLoading from 'dva-loading';

const runtimeDva = window.g_plugins.mergeConfig('dva');
let app = dva({
  history: window.g_history,
  
  ...(runtimeDva.config || {}),
});

window.g_app = app;
app.use(createLoading());
(runtimeDva.plugins || []).forEach(plugin => {
  app.use(plugin);
});

app.model({ namespace: 'areaHelp', ...(require('/home/lzt/Project/codeTools-UI/src/models/areaHelp.js').default) });
app.model({ namespace: 'areaHelpCategory', ...(require('/home/lzt/Project/codeTools-UI/src/models/areaHelpCategory.js').default) });
app.model({ namespace: 'currentOperator', ...(require('/home/lzt/Project/codeTools-UI/src/models/currentOperator.js').default) });
app.model({ namespace: 'dapperbyselfbuildcreator', ...(require('/home/lzt/Project/codeTools-UI/src/models/dapperbyselfbuildcreator.js').default) });
app.model({ namespace: 'dashboard', ...(require('/home/lzt/Project/codeTools-UI/src/models/dashboard.js').default) });
app.model({ namespace: 'folder', ...(require('/home/lzt/Project/codeTools-UI/src/models/folder.js').default) });
app.model({ namespace: 'global', ...(require('/home/lzt/Project/codeTools-UI/src/models/global.js').default) });
app.model({ namespace: 'login', ...(require('/home/lzt/Project/codeTools-UI/src/models/login.js').default) });
app.model({ namespace: 'menu', ...(require('/home/lzt/Project/codeTools-UI/src/models/menu.js').default) });
app.model({ namespace: 'metaData', ...(require('/home/lzt/Project/codeTools-UI/src/models/metaData.js').default) });
app.model({ namespace: 'nhibernatecreator', ...(require('/home/lzt/Project/codeTools-UI/src/models/nhibernatecreator.js').default) });
app.model({ namespace: 'setting', ...(require('/home/lzt/Project/codeTools-UI/src/models/setting.js').default) });
app.model({ namespace: 'sqlserver', ...(require('/home/lzt/Project/codeTools-UI/src/models/sqlserver.js').default) });
app.model({ namespace: 'user', ...(require('/home/lzt/Project/codeTools-UI/src/models/user.js').default) });
