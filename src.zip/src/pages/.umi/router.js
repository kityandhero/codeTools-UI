import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from '/home/lzt/Project/codeTools-UI/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/home/lzt/Project/codeTools-UI/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import('../User/Login'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/user/register",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/home/lzt/Project/codeTools-UI/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import('../User/Register'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/user/register-result",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/home/lzt/Project/codeTools-UI/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import('../User/RegisterResult'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/BasicLayout'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
    "Routes": [require('../Authorized').default],
    "routes": [
      {
        "path": "/",
        "redirect": "/dashboard/analysis",
        "exact": true
      },
      {
        "path": "/dashboard",
        "name": "dashboard",
        "icon": "dashboard",
        "routes": [
          {
            "path": "/dashboard/analysis",
            "name": "analysis",
            "icon": "area-chart",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/home/lzt/Project/codeTools-UI/src/pages/Dashboard/models/activities.js').then(m => { return { namespace: 'activities',...m.default}}),
  import('/home/lzt/Project/codeTools-UI/src/pages/Dashboard/models/chart.js').then(m => { return { namespace: 'chart',...m.default}}),
  import('/home/lzt/Project/codeTools-UI/src/pages/Dashboard/models/monitor.js').then(m => { return { namespace: 'monitor',...m.default}})
],
  component: () => import('../Dashboard/Analysis'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/database",
        "name": "database",
        "icon": "database",
        "routes": [
          {
            "path": "/database/sqlServer",
            "name": "sqlServer",
            "component": _dvaDynamic({
  
  component: () => import('../SqlServer/OperationPlate'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "name": "helpCenter",
        "icon": "question",
        "path": "/helpCenter",
        "routes": [
          {
            "path": "/helpCenter/category",
            "name": "category",
            "icon": "form",
            "redirect": "/helpCenter/category/no",
            "exact": true
          },
          {
            "path": "/helpCenter/category/:categoryId",
            "hideInMenu": true,
            "component": _dvaDynamic({
  
  component: () => import('../HelpCenter'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
            "routes": [
              {
                "path": "/helpCenter/category/:categoryId",
                "redirect": "/helpCenter/category/:categoryId/list",
                "exact": true
              },
              {
                "path": "/helpCenter/category/:categoryId/list",
                "component": _dvaDynamic({
  
  component: () => import('../HelpCenter/List'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "path": "/helpCenter/category/:categoryId/detail/:id/:pageKey",
                "component": _dvaDynamic({
  
  component: () => import('../HelpCenter/Detail'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
                "exact": true
              },
              {
                "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
              }
            ]
          },
          {
            "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": _dvaDynamic({
  
  component: () => import('../404'),
  LoadingComponent: require('/home/lzt/Project/codeTools-UI/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('/home/lzt/Project/codeTools-UI/node_modules/_umi-build-dev@1.8.3@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  window.g_plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
window.g_history.listen(routeChangeHandler);
routeChangeHandler(window.g_history.location);

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
